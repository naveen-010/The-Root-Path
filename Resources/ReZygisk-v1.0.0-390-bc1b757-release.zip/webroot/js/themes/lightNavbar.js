export function setLightNav() {
  document.getElementById('ni_home').classList.add('light')
  document.getElementById('ni_modules').classList.add('light')
  document.getElementById('ni_actions').classList.add('light')
  document.getElementById('ni_settings').classList.add('light')
}
