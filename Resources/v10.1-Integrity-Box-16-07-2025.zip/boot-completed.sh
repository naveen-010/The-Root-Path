#!/system/bin/sh
# Set log level for LSPosed
#tags=("LSPosed" "LSPosed-Bridge")
#for tag in "${tags[@]}"; do
#    setprop persist.log.tag."$tag" S
#done

# Define popup
#popup() {
#    am start -a android.intent.action.MAIN -e mona "$@" -n popup.toast/meow.helper.MainActivity > /dev/null
#    sleep 0.5
#}

resetprop -p --delete persist.log.tag.LSPosed
resetprop -p --delete persist.log.tag.LSPosed-Bridge

# su -c 'getprop | grep -E "pihook|pixelprops" | sed -E "s/^\[(.*)\]:.*/\1/" | while IFS= read -r prop; do resetprop -p -d "$prop"; done'

# Wait for system to stabilize before setting SELinux
#sleep 10

# Try to set SELinux to enforcing if permissive 
#if command -v setenforce >/dev/null 2>&1; then
#    current=$(getenforce)
#    if [ "$current" != "Enforcing" ]; then
#        setenforce 1
#        popup "Spoofed Selinux to ENFORCING"
#    fi
#fi

exit 0
